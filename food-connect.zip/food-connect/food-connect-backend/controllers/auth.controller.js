// Import the User model to interact with the 'users' collection in MongoDB.
import User from "../models/User.js";

// Import bcryptjs to securely hash and compare passwords.
import bcrypt from "bcryptjs";

// Import a utility function to generate JWT tokens for authenticated users.
import generateToken from "../utils/generateToken.js";


// =====================
//  SIGNUP CONTROLLER
// =====================
export const signup = async (req, res) => {
  try {
    // Extract name, email, password, and role from the request body.
    // These come from the frontend signup form.
    const { name, email, password, role } = req.body;

    // Check if a user with the same email already exists in the database.
    const userExists = await User.findOne({ email });
    if (userExists) {
      // If yes, send a 400 (Bad Request) response with an error message.
      return res.status(400).json({ message: "User already exists" });
    }

    // Generate a salt (random value) and hash the password with it.
    // Hashing protects the password so it’s not stored as plain text in the database.
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Create a new user in the database with the hashed password.
    const user = await User.create({
      name,
      email,
      password: hashedPassword,
      role
    });

    // Return a success response with the user details and a generated JWT token.
    // The token will be used for authentication in later API calls.
    res.status(201).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      token: generateToken(user._id)
    });
  } catch (error) {
    // If any unexpected error occurs, send a 500 (Internal Server Error) response.
    res.status(500).json({ message: error.message });
  }
};


// =====================
//  LOGIN CONTROLLER
// =====================
export const login = async (req, res) => {
  try {
    // Extract email and password from the request body.
    const { email, password } = req.body;

    // Check if a user with the provided email exists.
    const user = await User.findOne({ email });
    if (!user)
      return res.status(400).json({ message: "Invalid email or password" });

    // Compare the plain password entered by the user with the hashed one in the DB.
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch)
      return res.status(400).json({ message: "Invalid email or password" });

    // If everything is correct, return the user details and a JWT token.
    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      token: generateToken(user._id)
    });
  } catch (error) {
    // Handle any server errors gracefully.
    res.status(500).json({ message: error.message });
  }
};
