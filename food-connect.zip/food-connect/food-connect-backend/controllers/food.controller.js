import Food from "../models/Food.js";

// ➡ Add new food
export const createFood = async (req, res) => {
  try {
    const { name, description, quantity, location } = req.body;
    const image = req.file ? req.file.path : null;

    const food = await Food.create({
      name,
      description,
      quantity,
      location,
      donor: req.userId,
      
    });

    res.status(201).json(food);
  } catch (error) {
    res.status(500).json({ message: "Error creating food" });
  }
};

// ➡ Get all foods
export const getFoods = async (req, res) => {
  try {
    const foods = await Food.find().populate("donor", "name email");
    res.status(200).json(foods);
  } catch (error) {
    res.status(500).json({ message: "Error fetching foods", error: error.message });
  }
};

// ➡ Update food
export const updateFood = async (req, res) => {
  try {
    const food = await Food.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!food) return res.status(404).json({ message: "Food not found" });
    res.json(food);
  } catch (error) {
    res.status(500).json({ message: "Error updating food", error: error.message });
  }
};

// ➡ Delete food
export const deleteFood = async (req, res) => {
  try {
    const food = await Food.findByIdAndDelete(req.params.id);
    if (!food) return res.status(404).json({ message: "Food not found" });
    res.json({ message: "Food deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Error deleting food", error: error.message });
  }
};
