import Request from "../models/Request.js";

// ➡ Create a new request (by taker)
export const createRequest = async (req, res) => {
  try {
    const { foodId } = req.body;

    const request = new Request({
      food: foodId,
      requester: req.userId,
    });

    await request.save();
    res.status(201).json({ message: "Request created successfully", request });
  } catch (error) {
    res.status(500).json({ message: "Error creating request", error: error.message });
  }
};

// ➡ Get all requests for a donor's foods
export const getRequestsForDonor = async (req, res) => {
  try {
    const requests = await Request.find()
      .populate({
        path: "food",
        match: { donor: req.userId },
      })
      .populate("requester", "name email");

    const filtered = requests.filter((r) => r.food);
    res.status(200).json(filtered);
  } catch (error) {
    res.status(500).json({ message: "Error fetching requests", error: error.message });
  }
};

// ➡ Update request status (accept/reject) by donor
export const updateRequestStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const request = await Request.findById(req.params.id).populate("food");

    if (!request) return res.status(404).json({ message: "Request not found" });
    if (request.food.donor.toString() !== req.userId)
      return res.status(403).json({ message: "Not authorized" });

    request.status = status;
    await request.save();

    res.json({ message: "Request status updated", request });
  } catch (error) {
    res.status(500).json({ message: "Error updating request", error: error.message });
  }
};
