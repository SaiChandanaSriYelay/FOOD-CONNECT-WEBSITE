// Import mongoose — an ODM (Object Data Modeling) library for MongoDB.
// It helps you define schemas, models, and interact with MongoDB easily using JavaScript.
import mongoose from "mongoose";

// Import dotenv to load environment variables (like MONGO_URI) from the .env file.
import dotenv from "dotenv";

// Load environment variables into process.env
dotenv.config();

// Define an asynchronous function to connect to the MongoDB database
const connectDB = async () => {
  try {
    // Try to connect to MongoDB using the MONGO_URI value from .env file.
    // mongoose.connect() returns a promise that resolves to the connection object.
    const conn = await mongoose.connect(process.env.MONGO_URI);

    // If connection is successful, log the MongoDB host name in the console.
    console.log(`MongoDB connected: ${conn.connection.host}`);
  } catch (error) {
    // If there’s an error (e.g., wrong URI, MongoDB not running),
    // log a clear error message for debugging.
    console.error("MongoDB connection error:", error.message);

    // Exit the process with failure code (1) so the developer knows something went wrong.
    process.exit(1);
  }
};

// Export the connectDB function so it can be imported and used in server.js
export default connectDB;
