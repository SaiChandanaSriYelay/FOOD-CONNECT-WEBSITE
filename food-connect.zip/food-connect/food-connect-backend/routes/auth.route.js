// Import express to create a router for handling specific routes.
import express from "express";

// Import the controller functions that actually handle the logic 
// when someone hits the signup or login API endpoints.
import { signup, login } from "../controllers/auth.controller.js";

// Create a new Express router instance to define routes in this file.
const router = express.Router();

// Define the route for user signup.
// When a POST request is made to /api/auth/signup,
// the signup() function from auth.controller.js will handle it.
router.post("/signup", signup);

// Define the route for user login.
// When a POST request is made to /api/auth/login,
// the login() function from auth.controller.js will handle it.
router.post("/login", login);

// Export the router so it can be used in server.js
// (in server.js it is imported as 'authRoutes' and used with app.use("/api/auth", authRoutes))
export default router;
