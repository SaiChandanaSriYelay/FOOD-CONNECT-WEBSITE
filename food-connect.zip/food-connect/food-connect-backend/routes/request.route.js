import express from "express";
import { verifyToken } from "../middleware/verifyToken.js";
import {
  createRequest,
  getRequestsForDonor,
  updateRequestStatus,
} from "../controllers/request.controller.js";

const router = express.Router();

router.post("/", verifyToken, createRequest);
router.get("/donor", verifyToken, getRequestsForDonor);
router.put("/:id", verifyToken, updateRequestStatus);

export default router;
