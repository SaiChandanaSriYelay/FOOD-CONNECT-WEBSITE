import express from "express";
import { verifyToken } from "../middleware/verifyToken.js";
import upload from "../middleware/upload.js";
import {
  createFood,
  getFoods,
  updateFood,
  deleteFood,
} from "../controllers/food.controller.js";

const router = express.Router();

// Upload image + food info
router.post("/", verifyToken, upload.single("image"), createFood);
router.get("/", getFoods);
router.put("/:id", verifyToken, updateFood);
router.delete("/:id", verifyToken, deleteFood);

export default router;
