import mongoose from "mongoose";



const foodSchema = new mongoose.Schema({

  name: {

    type: String,

    required: true,

  },

  description: String,

  quantity: {

    type: Number,

    required: true,

  },

  location: {

    type: String,

    required: true,

  },

  donor: {

    type: mongoose.Schema.Types.ObjectId,

    ref: "User", // who is giving the food

    required: true,

  },

  createdAt: {

    type: Date,

    default: Date.now,

  },

});



const Food = mongoose.model("Food", foodSchema);

export default Food;