// Importing the required modules
import express from "express";        // Import Express — the core framework for building the backend server and handling routes.
import dotenv from "dotenv";          // Import dotenv — used to load environment variables from a .env file.
import cors from "cors";              // Import CORS — allows frontend apps (like React) to communicate with this backend safely.
import connectDB from "./config/db.js"; // Import the MongoDB connection function from the config folder.

// Importing route files (which handle specific parts of the app)
import authRoutes from "./routes/auth.route.js";       // Routes for user authentication (signup, login, etc.)
import foodRoutes from "./routes/food.route.js";       // Routes for handling food-related operations (add, fetch, delete food, etc.)
import requestRoutes from "./routes/request.route.js"; // Routes for handling food requests made by users.

// Load environment variables (like MONGO_URI, PORT) from the .env file into process.env
dotenv.config();

// Connect to the MongoDB database using the function imported above
connectDB();

// Initialize the Express application
const app = express();

// Middleware to automatically parse incoming JSON request bodies
// Example: converts { "name": "apple" } in the request into a JS object we can access as req.body.name
app.use(express.json());

// Enable Cross-Origin Resource Sharing so that frontend (different domain) can call backend APIs
app.use(cors());

// Define a test route for the root URL
// When user visits http://localhost:5000/, this message will appear in the browser
app.get("/", (req, res) => res.send("Food Connect Backend — up and running"));

// Serve uploaded files statically from the 'uploads' folder
// Example: if a file is saved as uploads/image.png, it can be accessed at http://localhost:5000/uploads/image.png
app.use("/uploads", express.static("uploads"));

// Register API routes for authentication, food, and requests
// Any endpoint starting with /api/auth will go to authRoutes file
// Any endpoint starting with /api/foods will go to foodRoutes file
// Any endpoint starting with /api/requests will go to requestRoutes file
app.use("/api/auth", authRoutes);
app.use("/api/foods", foodRoutes);
app.use("/api/requests", requestRoutes);

// Choose the port from environment variable or default to 5000
const PORT = process.env.PORT || 5000;

// Start the server and listen on the specified port
// Once server starts, log the message to console
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
