import { request, showModal } from "./api.js";

// Fetch requests for donor
export async function fetchRequests() {
  try {
    const data = await request("/requests/donor", "GET");
    const tbody = document.querySelector("#requestsTable tbody");
    tbody.innerHTML = "";
    data.forEach((r) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${r.food.name}</td>
        <td>${r.taker.name}</td>
        <td>${r.status}</td>
        <td>
          ${
            r.status === "pending"
              ? `<button class="btn" onclick="updateRequest('${r._id}','accepted')">Accept</button>
                 <button class="btn" onclick="updateRequest('${r._id}','rejected')">Reject</button>`
              : "-"
          }
        </td>
      `;
      tbody.appendChild(tr);
    });
  } catch (err) {
    showModal(err.message || "Failed to load requests");
  }
}

// Update request status
export async function updateRequest(id, status) {
  try {
    await request("/requests/" + id, "PUT", { status });
    showModal("Updated successfully");
    fetchRequests();
  } catch (err) {
    showModal(err.message || "Failed to update");
  }
}

// Logout function
export function logout() {
  localStorage.removeItem("token");
  window.location.href = "login.html";
}

// Initialize fetch if table exists
if (document.querySelector("#requestsTable tbody")) {
  fetchRequests();
}
