import { request, showModal } from "./api.js";

// Fetch all foods
export async function fetchFoods() {
  try {
    const foods = await request("/foods", "GET");
    const container = document.getElementById("foodList");
    container.innerHTML = "";
    foods.forEach((food) => {
      const div = document.createElement("div");
      div.className = "card";
      div.innerHTML = `
        ${food.image ? `<img src="http://localhost:5000/${food.image}" alt="${food.name}">` : ""}
        <h3>${food.name}</h3>
        <p>${food.description}</p>
        <p>Quantity: ${food.quantity}</p>
        <p>Location: ${food.location}</p>
        <button class="btn" onclick="requestFood('${food._id}')">Request</button>
      `;
      container.appendChild(div);
    });
  } catch (err) {
    showModal(err.message || "Failed to load foods");
  }
}

// Request a food item
export async function requestFood(id) {
  try {
    await request("/requests", "POST", { foodId: id });
    showModal("Food requested successfully");
    fetchFoods(); // refresh list
  } catch (err) {
    showModal(err.message || "Request failed");
  }
}
