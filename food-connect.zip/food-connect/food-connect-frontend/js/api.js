const BASE_URL = "http://localhost:5000/api";

// Generic API request function
function request(url, method = "GET", data = null) {
  const token = localStorage.getItem("token");
  const headers = {};

  if (data && !(data instanceof FormData)) headers["Content-Type"] = "application/json";
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const options = { method, headers };
  if (data) {
    options.body = data instanceof FormData ? data : JSON.stringify(data);
  }

  return fetch(BASE_URL + url, options)
    .then(async (res) => {
      const json = await res.json();
      if (!res.ok) throw json;
      return json;
    });
}

// Modal functions
function showModal(message) {
  const modal = document.getElementById("modal");
  const content = document.getElementById("modalContent");
  content.innerHTML = `
    <p>${message}</p>
    <button class="btn" id="modalCloseBtn">Close</button>
  `;
  modal.style.display = "flex";

  document.getElementById("modalCloseBtn").addEventListener("click", closeModal);
}

function closeModal() {
  document.getElementById("modal").style.display = "none";
}

// Make global
window.request = request;
window.showModal = showModal;
window.closeModal = closeModal;
