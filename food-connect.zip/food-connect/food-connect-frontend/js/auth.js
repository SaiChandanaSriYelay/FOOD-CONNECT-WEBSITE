// Signup Form
const signupForm = document.getElementById("signupForm");
if (signupForm) {
  signupForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const formData = new FormData(signupForm);
    const data = {
      name: formData.get("name"),
      email: formData.get("email"),
      password: formData.get("password"),
      role: formData.get("role"),
    };

    try {
      await request("/auth/signup", "POST", data);
      showModal("Signup successful! Redirecting to login...");
      setTimeout(() => {
        window.location.href = "login.html";
      }, 1000);
    } catch (err) {
      showModal(err.message || "Signup failed");
    }
  });
}

// Login Form
const loginForm = document.getElementById("loginForm");
if (loginForm) {
  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const formData = new FormData(loginForm);
    const data = {
      email: formData.get("email"),
      password: formData.get("password"),
    };

    try {
      const res = await request("/auth/login", "POST", data);
      localStorage.setItem("token", res.token);
      showModal("Login successful! Redirecting to home...");
      setTimeout(() => {
        window.location.href = "home.html";
      }, 1000);
    } catch (err) {
      showModal(err.message || "Login failed");
    }
  });
}

// Logout function
function logout() {
  localStorage.removeItem("token");
  window.location.href = "login.html";
}

// Make global
window.logout = logout;
